package pack1;

import java.time.LocalDate;

public class Producto {
    private String Nombre, Estatus; 
    LocalDate Fecha, Dias_Caducidad;
    int indice, Id;
    private double PrecioMa, PrecioMe, Cantidad;
    
    public Producto(String Nombre, String Estatus, LocalDate Fecha,int Id, double PrecioMa, double PrecioMe, double Cantidad, LocalDate Dias_Caducidad, int indice){
        this.Nombre = Nombre;
        this.Estatus = Estatus;
        this.Fecha = Fecha;
        this.Id = Id;
        this.PrecioMa = PrecioMa;
        this.PrecioMe = PrecioMe;
        this.Cantidad = Cantidad;
        this.Dias_Caducidad = Dias_Caducidad;
        this.indice = indice;
    }
    
    public String Mensaje(){
        return "Nombre: " + Nombre +
        "\nEstatus: " + Estatus + 
        "\nFecha: " + Fecha +
        "\nId: " + Id +  
        "\nPrecio mayoreo: " + PrecioMa +  
        "\nPrecio menudeo: " + PrecioMe +  
        "\nCantidad de producto en una caja: " + Cantidad +  
        "\nDias de caducidad: " + Dias_Caducidad;  
    }

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }
    
    public void setCantidad(String Cantidad) {
        double cantidad=-1;
        try{
            cantidad = Double.parseDouble(Cantidad);
        } catch(NumberFormatException e){
            System.out.println("Ingrese un valor numerico valido.");
        }
        
        this.Cantidad = cantidad;
    }
    
    public double ActCantidad(double cantidad){
        Cantidad += cantidad;
        return Cantidad;
    }
    
    public void setId(int Id) {
        this.Id = Id;
    }

    public void setEstatus(String Estatus) {
        this.Estatus = Estatus;
    }

    public void setFecha(LocalDate Fecha) {
        this.Fecha = Fecha;
    }
    
    public void setNombre(String Nombre) {
        this.Nombre = Nombre.toUpperCase();
    }

    public void setPrecioMa(String PrecioMa) {
        double precioMa=-1;
        try{
            precioMa = Double.parseDouble(PrecioMa);
        }catch(NumberFormatException e){
            System.out.println("Ingrese un numero valido.");
        }
        
        this.PrecioMa = precioMa;
    }

    public void setPrecioMe(String PrecioMe) {
        double precioMe=-1;
        try{
            precioMe = Double.parseDouble(PrecioMe);
        }catch(NumberFormatException e){
            System.out.println("Ingrese un numero valido.");
        }
        
        this.PrecioMa = precioMe;
    }

    public void setDias_Caducidad(LocalDate Dias_Caducidad) {
        this.Dias_Caducidad = Dias_Caducidad;
    }

    public double getPrecioMa() {
        return PrecioMa;
    }

    public double getPrecioMe() {
        return PrecioMe;
    }

    public int getId() {
        return Id;
    }

    public String getEstatus(double cantidad) {
        if(cantidad <= 0){
            return Estatus = "No disponible";
        } else{
            return Estatus = "Disponible";
        }
    }

    public LocalDate getFecha() {
        return Fecha;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public double getCantidad() {
        return Cantidad;
    }

    public LocalDate getDias_Caducidad() {
        return Dias_Caducidad;
    }
}