package pack1;

import java.time.LocalDate;

public class Pedido {
    private LocalDate Fecha;
    private double Cantidad;
    private double Total;
    private String Nombre;
    private String Apellidos;
    private int Id;
    private String Estado;
    private int Cliente, Conductor;
    
    public Pedido(LocalDate Fecha, double Cantidad, double Total, String Nombre, String Apellidos, int Id, String Estado, int Cliente, int Conductor){
        this.Fecha = Fecha;
        this.Cantidad = Cantidad;
        this.Total = Total;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Id = Id;
        this.Estado = Estado;
        this.Cliente = Cliente;
        this.Conductor = Conductor;
    }
    
    public String Mensaje(){
        return "Nombre: " + Nombre + 
                "\nApellidos: " + Apellidos +
                "\nId de pedido: " + Id +
                "\nCantidad de productos: " + Cantidad +
                "\nTotal: " + Total +
                "\nFecha: " + Fecha + 
                "\nEstado: " + Estado +
                "\nConductor: " + Conductor;
    }

    public int getConductor() {
        return Conductor;
    }

    public void setConductor(int Conductor) {
        this.Conductor = Conductor;
    }

    public int getCliente() {
        return Cliente;
    }

    public void setCliente(int Cliente) {
        this.Cliente = Cliente;
    }

    
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    
    public LocalDate getFecha() {
        return Fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.Fecha = fecha;
    }

    public double getCantidad() {
        return Cantidad;
    }

    public void setCantidad(double cantidad) {
        
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double Total) {
        this.Total = Total;
    }
    
    
}
