package pack1;

public class Conductor extends Cliente{
    
    public Conductor(int Id, String Nombre, String Apellidos, String Telefono, String Direccion, String Email, String Contrasena, String Tipo_Vehiculo){
        super(Id, Nombre, Apellidos, Telefono, Direccion, Email, Contrasena);
    }

    public String mensajeCN(){
        return "Nombre: " + getNombre() +
        "\nApellidos: " + getApellidos() + 
        "\nId: " + getId() + 
        "\nEmail: " + getEmail() +
        "\nTelefono: " + getTelefono() + 
        "\nDireccion: " + getDireccion() +
        "\nContraseña: " + getContrasena();
    }
}
