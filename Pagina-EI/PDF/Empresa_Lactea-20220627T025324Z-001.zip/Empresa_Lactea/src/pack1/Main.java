package pack1;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        LocalDate date = LocalDate.now();
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        //Productos
        Producto pr[] = new Producto[40];
        pr[0] = new Producto("LECHE 1 LITRO", "",date, 1, 15, 34.00, 10, (date.plusDays(10)), 0);
        pr[1] = new Producto("QUESO 1 KG", "",date, 2, 80, 34.00, 10, (date.plusDays(10)), 0);
        for(int i=2;i<pr.length;i++){
            pr[i] = new Producto(null, null, null, i+1, -1, -1, -1, null, i);
        }
        //Conductores
        Conductor cn[] = new Conductor[10];
        cn[0] = new Conductor(1, "CARLOS", "GARCIA CARRILLO", "3311205787", "Miravalle", "carlos.garcia@gmail.com", "00001", "");
        for(int i=1;i<cn.length;i++){
            cn[i] = new Conductor(i+1, null, null, null, null, null, null, null);
        }
        //Clientes
        Cliente cl[] = new Cliente[10];
        cl[0] = new Cliente(1,"MANUEL","PEREZ ORTIZ","3312386203","Centro","manuel.perez01@gmail.com","12345");
        for(int i=1; i < cl.length; i++){
            cl[i] = new Cliente(i+1,null,null,null,null,null,null);
        }
        
        //Almacen
        Almacen al = new Almacen();
        
        //Vehiculo
        Vehiculo vn[] = new Vehiculo[20];
        vn[0] = new Vehiculo("Camioneta", "15678", "Servicio", 2); 
        vn[1] = new Vehiculo("Carro", "15678", "Servicio", 2); 
        
        //Pedido
        int[][] matriz = new int[41][15]; 
        for(int i=0; i<matriz.length; i++){
            for(int j=0; j<matriz[i].length; j++){
                if(i != 0){
                    matriz[i][j] = -1;
                } else{
                    matriz[i][j] = j;
                }
            }
        }
        
        // Pedido
        Pedido pd[] = new Pedido[25];
        for(int i=0; i<pd.length; i++){
            pd[i] = new Pedido(null,0,0,null,null,i+1,null,-1, -1);
        }
        
        //variables
        int opcion, opcion1,indice=0, opcven=0, cantidad, indice_s=0, inte=0, indice_pedido=0, indice_cliente=0,indicepr=0, id=0, cambio=0,indice_inicial=0, indice_conductor=0, indice_conductorS=0, ind=0;
        String valorI, con ,valor;
        boolean band;
        double total=0, cont=0;
        ImageIcon icono = new ImageIcon("/home/destroller/NetBeansProjects/Empresa_Lactea/Empresa.png");
        ImageIcon iconocheck = new ImageIcon("/home/destroller/NetBeansProjects/Empresa_Lactea/lista_de_verificacion.png");
        ImageIcon iconoverificacion = new ImageIcon("/home/destroller/NetBeansProjects/Empresa_Lactea/lista-de-verificacion.png");
        
        //variables de ventanas
        String [] arreglo = {"Conductor","Cliente","Almacen","Cerrar sesion"};
        String [] arregloC = {"Agregar conductor","borrar conductor","Editar conductor","Visualizar conductor", "Ver pedidos", "pantalla de inicio"};
        String [] arregloCl = {"Registrarse","Borrar cuenta", "Iniciar sesion","pantalla de inicio"};
        String [] arregloMenuC = {"Nombre","Apellidos","Telefono","Domicilio","Email","Contraseña", "cerrar sesion"};
        String [] arregloMenuCl = {"Nombre","Apellidos","Telefono","Domicilio","Email","Contraseña","Id", "cerrar sesion"};
        String [] arregloClSubMenu = {"Ver mi perfil","Hacer pedido", "Mis pedidos","Ver productos","Cerrar sesion"};
        String [] arregloAl = {"Agregar materia prima", "Ver productos", "Cerrar sesion"};
        
        do{
        band = false;    
        opcion = JOptionPane.showOptionDialog(null, "¿A donde quiere ingresar?", "Pantalla inicial",0 , JOptionPane.QUESTION_MESSAGE, icono, arreglo, "");
        
        switch(opcion){
            case 0: //submenu conductores
                
                do{
                opcion1 = JOptionPane.showOptionDialog(null, "¿Que quiere hacer?", "Pantalla de conductores",0 , JOptionPane.QUESTION_MESSAGE, icono, arregloC, "");
                
                switch(opcion1){
                    case 0: //agregar nuevo conductor
                        int intento=0;
                        for(int i=1;i<cn.length;i++){
                            if(cn[i].getNombre() == null && intento == 0){
                                indice = i;
                                intento++;
                            }
                        }
                        
                        valorI = JOptionPane.showInputDialog(null, "Ingrese el nombre del conductor: "); cn[indice].setNombre(valorI); 
                        valorI = JOptionPane.showInputDialog(null, "Ingrese el Apellidos del conductor: "); cn[indice].setApellidos(valorI); 
                        valorI = JOptionPane.showInputDialog(null, "Ingrese el Telefono del conductor: "); cn[indice].setTelefono(valorI); 
                        valorI = JOptionPane.showInputDialog(null, "Ingrese el Direccion del conductor: "); cn[indice].setDireccion(valorI); 
                        valorI = JOptionPane.showInputDialog(null, "Ingrese el Email del conductor: "); cn[indice].setEmail(valorI);  
                        valorI = JOptionPane.showInputDialog(null, "Ingrese la contraseña del conductor: "); cn[indice].setContrasena(valorI); 
                        
                        JOptionPane.showMessageDialog(null, "Conductor registrado con exito. Tu ID es el " + (cn[indice].getId()));
                        break;
                        
                    case 1: // borrar conductor
                        try{
                        valorI = JOptionPane.showInputDialog(null, "Ingresa el Id", "Borrando conductor", JOptionPane.YES_OPTION);
                        } catch(NullPointerException e){
                            break;
                        }
                        
                        cambio = Integer.parseInt(valorI);
                        
                        for(int i=0; i<cn.length; i++){
                            if(cambio == cn[i].getId()){
                                band = true;
                                indice = i;
                            }
                        }
                        if(band == true){
                            do{
                                con = JOptionPane.showInputDialog(null, "Agregue la contraseña del conductor: ", JOptionPane.OK_OPTION);
                            } while(cn[indice].getContrasena().equals(con) == false);
                            
                            opcven = JOptionPane.showConfirmDialog(null, "¿Quiere seguir borrando al conductor?", "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null);
                            
                            if(opcven == 0){
                                cn[indice] = new Conductor(indice, null, null, null, null, null, null, null);
                                JOptionPane.showConfirmDialog(null, "El conductor fue borrado exitosamente", "Borrado", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, iconocheck);
                                break;
                            } else {
                                JOptionPane.showMessageDialog(null, "El conductor no se ha borrado");
                                break;
                            }                           
                        } else{
                            JOptionPane.showMessageDialog(null, "Valor no encontrado"); break;
                        }
                        
                    case 2: //Editar conductor
                        try{
                        indice_conductor = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa el Id del conductor", "Editando conductor", JOptionPane.YES_OPTION));
                        } catch(NullPointerException e){
                            break;
                        }
                        
                        for(int i=1; i<cn.length; i++){
                            if(indice_conductor == cn[i].getId()){
                                band = true;
                                indice = i-1;
                            }
                        }
                        
                        if(band == true){

                            do{
                            opcven = JOptionPane.showOptionDialog(null, "¿Adonde quiere ingresar?", "Bienvenido " + cn[indice].getNombre(),0 , JOptionPane.QUESTION_MESSAGE, null, arregloMenuC, "");
                            //"Nombre","Apellidos","Telefono","Domicilio","Email","Contraseña","Tipo de vehiculo","Id"
                            switch(opcven){
                                case 0:
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo nombre de conductor: ", "Editando nombre", JOptionPane.QUESTION_MESSAGE);
                                    cn[indice].setNombre(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se cambio el nombre exitosamente", "Operacion exitosa", JOptionPane.YES_OPTION, JOptionPane.YES_OPTION, null);
                                    break;
                                case 1:
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa los nuevos apellidos del conductor: ", "Editando Apellidos", JOptionPane.QUESTION_MESSAGE);
                                    cn[indice].setApellidos(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se cambio los apellidos exitosamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null);
                                    break;
                                case 2:  
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo telefono del conductor: ", "Editando Telefono", JOptionPane.QUESTION_MESSAGE);
                                    cn[indice].setTelefono(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se cambio el telefono exitosamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null);
                                    break;
                                case 3:
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo domicilio del conductor: ", "Editando domicilio", JOptionPane.QUESTION_MESSAGE);
                                    cn[indice].setDireccion(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se cambio el telefono exitosamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null);
                                    break;
                                case 4:
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo email del conductor: ", "Editando email", JOptionPane.QUESTION_MESSAGE);
                                    cn[indice].setEmail(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se cambio el email exitosamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null);
                                    break;
                                case 5:
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa la nueva contraseña del conductor: ", "Editando contraseña", JOptionPane.QUESTION_MESSAGE);
                                    cn[indice].setContrasena(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se cambio la contraseña exitosamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null);
                                    break;
                                case 6: break;
                                default: break;
                            }
                            } while(opcven != 6);
                        } else{
                            JOptionPane.showMessageDialog(null, "Cuenta no encontrada"); break;
                        }
                        break;
                    case 4: //ver pedidos
                        band = false;
                        valorI = JOptionPane.showInputDialog(null, "Introduce el Id del conductor: ");
                        
                        cambio = Integer.parseInt(valorI);
                        for(int i=1; i<cn.length; i++){
                            if(cambio == cn[i].getId()){
                                band = true;
                                indice = i;
                            }
                        }
                        
                        if(band == true){ //Id encontrado
                            valorI = JOptionPane.showInputDialog(null, "Introduce la contraseña del conductor: ");
                            
                            if(cn[indice].getContrasena().equals(valorI)){ //contraseña encontrada
                                    for(int j=0; j<pd.length; j++){
                                        if(cn[indice].getId() == pd[j].getConductor() && j < vn[indice].getMaximo()){
                                            JOptionPane.showMessageDialog(null, pd[j].Mensaje(), "Pedido " + j, JOptionPane.DEFAULT_OPTION, iconoverificacion);
                                        }
                                    }
                            } else{ //contraseña no encontrada
                                JOptionPane.showConfirmDialog(null, "Conductor no encontrado");
                                break;
                            }
                            
                        } else{ //Id no encontrado
                            JOptionPane.showConfirmDialog(null, "Conductor no encontrado");
                            break;
                        }
                        
                        break;
                    case 3: //Visualizar conductor
                        indice = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el indice de conductor a visualizar: "));
                        
                        for(int i=0; i<cn.length; i++){
                                if(cn[i].getId() == indice){
                                JOptionPane.showMessageDialog(null, cn[indice-1].mensajeCN());
                            }
                        }
                        
                        break;
                    case 5: 
                        break;   
                    default: break;
                  }// switch del submenu Conductor
                  } while(opcion1 != 5);
                  break;
            case 1: // cliente
                  
                do{
                  opcion1 = JOptionPane.showOptionDialog(null, "¿A donde quiere ingresar?", "Pantalla de cliente",0 , JOptionPane.QUESTION_MESSAGE, null, arregloCl, "");
                  //"Registrarse","Borrar cuenta", "Iniciar sesion","pantalla de inicio"
                      switch(opcion1){
                           case 0: // menu registrarse "Nombre","Apellidos","Telefono","Domicilio","Email","Contraseña","Id", "cerrar sesion"
                                    int intento = 0;
                                    for(int i=0; i<cl.length; i++){
                                        
                                        
                                        if(cl[i].getNombre() == null && intento == 0){
                                            indice = i;
                                            intento++;
                                        }
                                    }
                               
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo nombre de cliente: ", "Edicion", JOptionPane.QUESTION_MESSAGE);
                                    cl[indice].setNombre(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se establecio nombre correctamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.YES_OPTION, iconocheck);
                   
                                    valorI = JOptionPane.showInputDialog(null, "Ingresa los nuevos apellidos del cliente: ", "Editando Apellidos", JOptionPane.QUESTION_MESSAGE);
                                    cl[indice].setApellidos(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se establecio apellidos correctamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, iconocheck);

                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo telefono del cliente: ", "Editando Telefono", JOptionPane.QUESTION_MESSAGE);
                                    cl[indice].setTelefono(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se establecio telefono correctamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, iconocheck);

                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo domicilio del cliente: ", "Editando domicilio", JOptionPane.QUESTION_MESSAGE);
                                    cl[indice].setDireccion(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se establecio domicilio correctamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, iconocheck);

                                    valorI = JOptionPane.showInputDialog(null, "Ingresa el nuevo email del cliente: ", "Editando email", JOptionPane.QUESTION_MESSAGE);
                                    cl[indice].setEmail(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se establecio email correctamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, iconocheck);

                                    valorI = JOptionPane.showInputDialog(null, "Ingresa la nueva contraseña del cliente: ", "Editando contraseña", JOptionPane.QUESTION_MESSAGE);
                                    cl[indice].setContrasena(valorI);
                                    JOptionPane.showConfirmDialog(null, "Se establecio contraseña correctamente", "Operacion exitosa", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, iconocheck);
                                    
                                    JOptionPane.showMessageDialog(null, "Tu Id es el " + cl[indice].getId());

                                    break;
                           case 1: // menu borrar cuenta
                               valorI = JOptionPane.showInputDialog(null, "Ingrese el id del cliente", "Borrando cliente");
                               
                               indice_cliente = Integer.parseInt(valorI);
                               
                               for(int i=0; i<cn.length; i++){
                                    if(indice_cliente-1 == cl[i].getId()){
                                    band = true;
                                    indice = i;
                                    }
                                }
                               
                                if(band = true){
                                    valorI = JOptionPane.showInputDialog(null, "Ingrese su contraseña del cliente", "Borrando cliente");
                                    
                                    if(valorI.equals(cl[indice].getContrasena())){
                                        opcven = JOptionPane.showConfirmDialog(null, "¿Quiere seguir borrando al conductor?", "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null);
                                        
                                        if(opcven == 0){
                                            cl[indice] = new Cliente(indice, null,null,null,null,null,null);
                                            JOptionPane.showMessageDialog(null, "Cliente borrado exitosamente");
                                        break;
                                        } else{
                                            JOptionPane.showMessageDialog(null, "Cliente no borrado");
                                            break;
                                        }
                                    } else{
                                        JOptionPane.showMessageDialog(null, "Contraseña incorrecta");
                                        break;
                                    }
                                    
                                } else{
                                    JOptionPane.showMessageDialog(null, "Id no encontrado");
                                    break;
                                }
                           case 2: // Iniciar sesion
                               valorI = JOptionPane.showInputDialog(null, "Ingresa el id de cliente: ", "Inicio de sesion", JOptionPane.DEFAULT_OPTION);
                               cambio = Integer.parseInt(valorI);
                               for(int i=0; i<cn.length; i++){
                                    if(cambio == cl[i].getId()){
                                    band = true;
                                    indice = i;
                                    }
                                }
                               
                               indice_inicial = indice;
                               
                               if(band == true){
                                   indice_cliente = indice;
                                   id = indice_cliente;
                                   valorI = JOptionPane.showInputDialog(null, "Ingresa su contraseña: ", "Inicio de sesion", JOptionPane.DEFAULT_OPTION);
                                   
                                   if(valorI.equals(cl[indice].getContrasena())){
                                   
                                   do{
                                   opcven = JOptionPane.showOptionDialog(null, "Escoja una opcion", "Bienvenido " + cl[indice].getNombre(),0 , JOptionPane.QUESTION_MESSAGE, null, arregloClSubMenu, iconoverificacion);
                                   band = false;
                                   switch(opcven){
                                       case 0: //ver perfil
                                           JOptionPane.showMessageDialog(null, cl[indice].mensajeCL());
                                           break;
                                       case 1: //Hacer pedido
                                           
                                           do{
                                           valorI = JOptionPane.showInputDialog(null, "Ingrese el producto que quiere: ");
                                           
                                           for(int i=0; i<pr.length; i++){
                                               if(valorI.toUpperCase().equals(pr[i].getNombre())){
                                                   band = true;
                                                   indicepr = i;
                                               }
                                           }
                                           
                                           if(band == true){ //producto encontrado
                                               int punto;
                                               
                                               cantidad = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la cantidad de cajas a pedir el producto " + pr[indicepr].getNombre()));
                                               
                                               matriz[pr[indicepr].getIndice() + 1][indice_pedido] = cantidad; 
                                               
                                               cont += (cantidad * pr[indicepr].getCantidad());
                                               total += (pr[indicepr].getPrecioMa() * pr[indice].getCantidad()) * cantidad;
                                               
                                               opcven = JOptionPane.showConfirmDialog(null, "Quieres seguir agregando productos a tu pedido?", "Agregar", JOptionPane.OK_OPTION);
                                               
                                               switch(opcven){
                                                   case 0:
                                                       break;
                                                   case 1: 
                                                        pd[indice_pedido].setFecha(date);
                                                        pd[indice_pedido].setCantidad(cont);
                                                        pd[indice_pedido].setTotal(total);
                                                        pd[indice_pedido].setNombre(cl[indice_cliente].getNombre());
                                                        pd[indice_pedido].setApellidos(cl[indice_cliente].getApellidos());
                                                        pd[indice_pedido].setId(indice_pedido);
                                                        pd[indice_pedido].setEstado("En espera");
                                                        pd[indice_pedido].setCliente(id);
                                           
                                                        if(ind < vn[indice_conductorS].getMaximo()){
                                                            pd[indice_pedido].setConductor(indice_conductorS+1);
                                                            ind++;
                                                        } else{
                                                            indice_conductorS++;
                                                            ind=0;
                                                            pd[indice_pedido].setConductor(indice_conductorS+1);
                                                        }
                                                            
                                                        
                                                        
                                                        inte=0;
                                                        indice_pedido++;
                                                        total = 0;
                                                        break;
                                                   default: 
                                                        break;    
                                               }
                                           } else{ //producto no encontrado
                                               JOptionPane.showMessageDialog(null, "Producto no encontrado", "No encontrado", JOptionPane.DEFAULT_OPTION);
                                               break;
                                           }
                                           
                                           } while(opcven == 0);
                                           
                                           break;
                                       case 2: // Ver mis pedidos 
                                           for(int i=0; i<pd.length; i++){
                                               if(pd[i].getNombre() != null){
                                               if(pd[i].getNombre().equals(cl[indice_inicial].getNombre())){
                                                   JOptionPane.showMessageDialog(null, pd[i].Mensaje());
                                               }
                                               }
                                           }
                                           break;
                                       case 3: // ver productos
                                           valorI = JOptionPane.showInputDialog(null, "Ponga el nombre del producto: ","BUscando producto", JOptionPane.DEFAULT_OPTION);
                                           valorI = valorI.toUpperCase();
                                           boolean band1 = false;
                                           for(int i=0;i<pr.length;i++){
                                               if(valorI.equals(pr[i].getNombre())){
                                                   JOptionPane.showMessageDialog(null, pr[i].Mensaje());
                                                   band1 = true;
                                               }
                                           }
                                           
                                           if(band1 == false){
                                               JOptionPane.showMessageDialog(null, "Producto no encontrado");
                                               break;
                                           }
                                           break;
                                       case 4:
                                           JOptionPane.showMessageDialog(null, "Sesion cerrada correctamente");
                                       default:  break; 
                                   }
                                   
                                   }while(opcven != 4);
                                   
                                   }else {
                                       JOptionPane.showMessageDialog(null, "Contraseña incorrecta");
                                       break;
                                   }
                                   break;
                                   
                               } else{
                                   JOptionPane.showMessageDialog(null, "Id no encontrado");
                                   break;
                               } 
                               
                           case 3: 
                               break;
                           default: break;    
                           }
                  } while(opcion1 != 3); 
                  break;
            case 2: //Almacen
                valorI = JOptionPane.showInputDialog(null, "Ingrese el usuario del almacen:");
                
                if(al.getUsuario().equals(valorI)){//Comprobar usuario de almacen
                    valorI = JOptionPane.showInputDialog(null, "Ingrese el usuario del almacen:");
                    
                    if(al.getContraseña().equals(valorI)){//Comprobar contraseña de almacen
                        //"Agregar materia prima", "Ver productos", "Cerrar sesion"
                        opcven = JOptionPane.showOptionDialog(null, "¿A donde quiere ingresar?", "Pantalla inicial",0 , JOptionPane.QUESTION_MESSAGE, icono, arregloAl, "");
                        
                        switch(opcven){
                            case 0:
                                valorI = JOptionPane.showInputDialog(null, "Cual es la cantidad de materia prima a recibir?");
                                
                                al.setMateria_Prima(valorI);
                                al.setEstatus("");
                            case 1:
                                valorI = JOptionPane.showInputDialog(null, "Ponga el nombre del producto: ","Buscador", JOptionPane.DEFAULT_OPTION);
                                           valorI = valorI.toUpperCase();
                                           boolean band1 = false;
                                           for(int i=0;i<pr.length;i++){
                                               if(valorI.equals(pr[i].getNombre())){
                                                   JOptionPane.showMessageDialog(null, pr[i].Mensaje());
                                                   band1 = true;
                                               }
                                           }
                                           
                                           if(band1 == false){
                                               JOptionPane.showMessageDialog(null, "Producto no encontrado");
                                               break;
                                           }
                                           break;
                            case 2:
                                break;
                            default:  
                                break;
                        }
                    } else{//Contraseña
                        JOptionPane.showMessageDialog(null, "Contraseña no valida");
                        break;
                    }
                    
                } else{//Usuario
                    JOptionPane.showMessageDialog(null, "Usuario no valido");
                    break;
                }
                
                break;
            case 3: // cerrar sesion
                break;
            default: 
                break;
        }
        } while(opcion != 3);
    }
}