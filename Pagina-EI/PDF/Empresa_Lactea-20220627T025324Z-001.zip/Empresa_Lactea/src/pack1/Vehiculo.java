package pack1;

public class Vehiculo {
    private String Tipo;
    private String Matricula;
    private String Estado;
    private int Maximo;
    
    public Vehiculo(String Tipo, String Matricula, String Estado, int Maximo){
        this.Tipo = Tipo;
        this.Matricula = Matricula;
        this.Estado = Estado;
        this.Maximo = Maximo;
    }

    public int getMaximo() {
        return Maximo;
    }

    public void setMaximo(int Maximo) {
        this.Maximo = Maximo;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getMatricula() {
        return Matricula;
    }

    public void setMatricula(String Matricula) {
        this.Matricula = Matricula;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }
    
    
}
