package pack1;

public class Almacen {
    private double materia_Prima;
    private String estatus;
    private String usuario;
    private String Contraseña;
    
    public Almacen(){
        materia_Prima = 0.0;
        estatus = "";
        usuario = "Admin";
        Contraseña = "Admin";
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public void setMateria_Prima(String materia_Prima) {
        double cantidad=-1;
        try{
            cantidad = Double.parseDouble(materia_Prima);
        } catch(NumberFormatException e){
            
        }
        this.materia_Prima = cantidad;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

    public double getMateria_Prima() {
        return materia_Prima;
    }

    public String getEstatus() {
        return estatus;
    }
}
