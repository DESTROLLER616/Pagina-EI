package pack1;

public class Cliente {
    private String Nombre, Apellidos, Telefono, Direccion, Email, Contrasena;
    private int Id;

    public Cliente(int Id, String Nombre, String Apellidos, String Telefono, String Direccion, String Email, String Contrasena){
        this.Id = Id;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Telefono = Telefono;
        this.Direccion = Direccion;
        this.Email = Email;
        this.Contrasena = Contrasena;
    }
    
    public String mensajeCL(){
        return "Nombre: " + Nombre +
        "\nApellidos: " + Apellidos + 
        "\nId: " + Id + 
        "\nEmail: " + Email +
        "\nTelefono: " + Telefono +
        "\nDireccion: " + Direccion +
        "\nContraseña: " + Contrasena;        
    }
    
    public void setId(int Id) {
        this.Id = Id;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre.toUpperCase();
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos.toUpperCase();
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion.toUpperCase();
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setContrasena(String Contrasena) {
        this.Contrasena = Contrasena;
    }

    public int getId() {
        return Id;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public String getTelefono() {
        return Telefono;
    }

    public String getDireccion() {
        return Direccion;
    }

    public String getEmail() {
        return Email;
    }

    public String getContrasena() {
        return Contrasena;
    }
}
